
import { toast } from 'sonner';

// Types
export interface BusData {
  id: string;
  routeNumber: string;
  currentLocation: {
    lat: number;
    lng: number;
  };
  status: 'on-route' | 'at-depot' | 'maintenance';
  nextStop: string;
  passengerCount: number;
  fuelLevel: number;
  lastUpdated: string;
}

export interface RouteData {
  id: string;
  routeNumber: string;
  name: string;
  startPoint: string;
  endPoint: string;
  averageTime: number; // in minutes
  distance: number; // in km
  busCount: number;
  activeStatus: boolean;
}

export interface FeedbackData {
  id: string;
  name: string;
  email: string;
  phone?: string;
  feedbackType: string;
  message: string;
  createdAt: string;
  status: 'pending' | 'reviewed' | 'resolved';
}

// Mock API endpoints with simulated delays
const mockDelay = () => new Promise(resolve => setTimeout(resolve, Math.random() * 800 + 200));

// Fetch buses data
export const fetchBuses = async (): Promise<BusData[]> => {
  try {
    await mockDelay();
    
    // Generate random bus data
    const mockBuses: BusData[] = Array.from({ length: 20 }, (_, i) => ({
      id: `bus-${i+1}`,
      routeNumber: `${Math.floor(Math.random() * 100) + 1}`,
      currentLocation: {
        lat: 28.6139 + (Math.random() * 0.1 - 0.05), // Around Delhi
        lng: 77.2090 + (Math.random() * 0.1 - 0.05)
      },
      status: ['on-route', 'at-depot', 'maintenance'][Math.floor(Math.random() * 3)] as 'on-route' | 'at-depot' | 'maintenance',
      nextStop: ['Connaught Place', 'India Gate', 'Nehru Place', 'Lajpat Nagar', 'Karol Bagh'][Math.floor(Math.random() * 5)],
      passengerCount: Math.floor(Math.random() * 60),
      fuelLevel: Math.floor(Math.random() * 100),
      lastUpdated: new Date(Date.now() - Math.floor(Math.random() * 3600000)).toISOString()
    }));
    
    return mockBuses;
  } catch (error) {
    console.error('Error fetching buses:', error);
    toast.error('Failed to load bus data. Please try again.');
    return [];
  }
};

// Fetch routes data
export const fetchRoutes = async (): Promise<RouteData[]> => {
  try {
    await mockDelay();
    
    const mockRoutes: RouteData[] = [
      {
        id: 'route-1',
        routeNumber: '34',
        name: 'Connaught Place - Nehru Place',
        startPoint: 'Connaught Place',
        endPoint: 'Nehru Place',
        averageTime: 45,
        distance: 12.5,
        busCount: 8,
        activeStatus: true
      },
      {
        id: 'route-2',
        routeNumber: '38',
        name: 'Karol Bagh - Lajpat Nagar',
        startPoint: 'Karol Bagh',
        endPoint: 'Lajpat Nagar',
        averageTime: 55,
        distance: 14.2,
        busCount: 10,
        activeStatus: true
      },
      {
        id: 'route-3',
        routeNumber: '45',
        name: 'ISBT - Saket',
        startPoint: 'ISBT',
        endPoint: 'Saket',
        averageTime: 65,
        distance: 18.1,
        busCount: 12,
        activeStatus: true
      },
      {
        id: 'route-4',
        routeNumber: '72',
        name: 'Dwarka - Noida',
        startPoint: 'Dwarka',
        endPoint: 'Noida',
        averageTime: 90,
        distance: 35.6,
        busCount: 15,
        activeStatus: true
      },
      {
        id: 'route-5',
        routeNumber: '56',
        name: 'IGI Airport - New Delhi Railway Station',
        startPoint: 'IGI Airport',
        endPoint: 'New Delhi Railway Station',
        averageTime: 60,
        distance: 16.8,
        busCount: 7,
        activeStatus: true
      }
    ];
    
    return mockRoutes;
  } catch (error) {
    console.error('Error fetching routes:', error);
    toast.error('Failed to load route data. Please try again.');
    return [];
  }
};

// Submit feedback
export const submitFeedback = async (feedback: Omit<FeedbackData, 'id' | 'createdAt' | 'status'>): Promise<boolean> => {
  try {
    await mockDelay();
    
    // In a real app, this would be an API call to the backend
    console.log('Feedback submitted:', feedback);
    
    // Simulate API success
    return true;
  } catch (error) {
    console.error('Error submitting feedback:', error);
    toast.error('Failed to submit feedback. Please try again.');
    return false;
  }
};

// Fetch feedback data (for admin panel)
export const fetchFeedback = async (): Promise<FeedbackData[]> => {
  try {
    await mockDelay();
    
    // Generate mock feedback data
    const mockFeedback: FeedbackData[] = [
      {
        id: 'feedback-1',
        name: 'Rahul Sharma',
        email: 'rahul.sharma@example.com',
        phone: '+91 98765 43210',
        feedbackType: 'suggestion',
        message: 'I think it would be great if we could see the exact arrival time of the next bus on the mobile app.',
        createdAt: '2023-12-10T10:30:00.000Z',
        status: 'reviewed'
      },
      {
        id: 'feedback-2',
        name: 'Priya Patel',
        email: 'priya.patel@example.com',
        feedbackType: 'issue',
        message: 'The bus on Route 38 was significantly delayed yesterday. Is there a way to get notifications about delays?',
        createdAt: '2023-12-15T14:45:00.000Z',
        status: 'pending'
      },
      {
        id: 'feedback-3',
        name: 'Amit Singh',
        email: 'amit.singh@example.com',
        phone: '+91 87654 32109',
        feedbackType: 'general',
        message: 'I\'m impressed with the new system. The buses are much more punctual now!',
        createdAt: '2023-12-18T09:15:00.000Z',
        status: 'resolved'
      },
      {
        id: 'feedback-4',
        name: 'Neha Gupta',
        email: 'neha.gupta@example.com',
        feedbackType: 'suggestion',
        message: 'Could you add an option to see how crowded a bus is before it arrives? It would help in planning the journey.',
        createdAt: '2023-12-20T11:20:00.000Z',
        status: 'pending'
      },
      {
        id: 'feedback-5',
        name: 'Vikram Joshi',
        email: 'vikram.joshi@example.com',
        phone: '+91 76543 21098',
        feedbackType: 'partnership',
        message: 'Our company is interested in integrating our ride-sharing service with your bus schedule data. How can we proceed?',
        createdAt: '2023-12-22T16:30:00.000Z',
        status: 'pending'
      }
    ];
    
    return mockFeedback;
  } catch (error) {
    console.error('Error fetching feedback:', error);
    toast.error('Failed to load feedback data. Please try again.');
    return [];
  }
};

// Update feedback status (for admin panel)
export const updateFeedbackStatus = async (id: string, status: 'pending' | 'reviewed' | 'resolved'): Promise<boolean> => {
  try {
    await mockDelay();
    
    // In a real app, this would be an API call to the backend
    console.log(`Updating feedback ${id} status to ${status}`);
    
    // Simulate API success
    return true;
  } catch (error) {
    console.error('Error updating feedback status:', error);
    toast.error('Failed to update feedback status. Please try again.');
    return false;
  }
};

// Authentication functions
export const login = async (username: string, password: string): Promise<boolean> => {
  try {
    await mockDelay();
    
    // Simple mock authentication
    if (username === 'admin' && password === 'admin123') {
      // Store auth token in localStorage
      localStorage.setItem('absrms-auth', JSON.stringify({
        user: 'admin',
        token: 'mock-token-123',
        expires: Date.now() + 24 * 60 * 60 * 1000 // 24 hours
      }));
      return true;
    }
    
    toast.error('Invalid credentials');
    return false;
  } catch (error) {
    console.error('Login error:', error);
    toast.error('Authentication failed. Please try again.');
    return false;
  }
};

export const logout = (): void => {
  localStorage.removeItem('absrms-auth');
};

export const isAuthenticated = (): boolean => {
  const auth = localStorage.getItem('absrms-auth');
  if (!auth) return false;
  
  try {
    const authData = JSON.parse(auth);
    return authData.expires > Date.now();
  } catch {
    return false;
  }
};
