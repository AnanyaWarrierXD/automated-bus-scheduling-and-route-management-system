
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Bus } from 'lucide-react';
import { Button } from './ui/button';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center space-x-2">
            <Bus className="h-8 w-8 text-transit-blue" />
            <span className="font-bold text-xl text-transit-blue">ABSRMS</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex space-x-8">
            <Link to="/" className="text-gray-700 hover:text-transit-blue font-medium transition">
              Home
            </Link>
            <Link to="/dashboard" className="text-gray-700 hover:text-transit-blue font-medium transition">
              Dashboard
            </Link>
            <Link to="/admin" className="text-gray-700 hover:text-transit-blue font-medium transition">
              Admin
            </Link>
            <Link to="/contact" className="text-gray-700 hover:text-transit-blue font-medium transition">
              Contact
            </Link>
          </div>

          {/* Mobile Navigation Button */}
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Menu">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden mt-4 pb-4 animate-fade-in">
            <div className="flex flex-col space-y-4">
              <Link to="/" className="text-gray-700 hover:text-transit-blue font-medium transition px-4 py-2 rounded-md hover:bg-gray-100" onClick={toggleMenu}>
                Home
              </Link>
              <Link to="/dashboard" className="text-gray-700 hover:text-transit-blue font-medium transition px-4 py-2 rounded-md hover:bg-gray-100" onClick={toggleMenu}>
                Dashboard
              </Link>
              <Link to="/admin" className="text-gray-700 hover:text-transit-blue font-medium transition px-4 py-2 rounded-md hover:bg-gray-100" onClick={toggleMenu}>
                Admin
              </Link>
              <Link to="/contact" className="text-gray-700 hover:text-transit-blue font-medium transition px-4 py-2 rounded-md hover:bg-gray-100" onClick={toggleMenu}>
                Contact
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
