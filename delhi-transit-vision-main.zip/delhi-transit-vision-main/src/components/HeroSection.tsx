
import { Bus, MapPin, Clock, TrendingUp } from 'lucide-react';
import { Button } from './ui/button';
import { Link } from 'react-router-dom';

const HeroSection = () => {
  return (
    <div className="relative bg-gradient-to-r from-blue-900 to-blue-700 text-white">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute h-1 left-0 right-0 bg-gray-200 opacity-10 top-1/4"></div>
        <div className="absolute h-1 left-0 right-0 bg-gray-200 opacity-10 top-2/4"></div>
        <div className="absolute h-1 left-0 right-0 bg-gray-200 opacity-10 top-3/4"></div>
        <div className="absolute w-1 top-0 bottom-0 bg-gray-200 opacity-10 left-1/4"></div>
        <div className="absolute w-1 top-0 bottom-0 bg-gray-200 opacity-10 left-2/4"></div>
        <div className="absolute w-1 top-0 bottom-0 bg-gray-200 opacity-10 left-3/4"></div>
        
        {/* Animated bus */}
        <div className="absolute top-1/4 left-0 w-6 h-6 animate-bus-moving">
          <Bus className="text-transit-orange" />
        </div>
        
        {/* Some animated dots representing transit nodes */}
        <div className="absolute top-1/4 left-1/4 w-3 h-3 rounded-full bg-transit-green animate-pulse-slow"></div>
        <div className="absolute top-2/4 left-2/4 w-3 h-3 rounded-full bg-transit-orange animate-pulse-slow"></div>
        <div className="absolute top-3/4 left-3/4 w-3 h-3 rounded-full bg-transit-teal animate-pulse-slow"></div>
      </div>
      
      <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div className="space-y-8">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              Smart Transit Solutions for Delhi
            </h1>
            <p className="text-xl text-blue-100">
              ABSRMS revolutionizes public transport with AI-powered scheduling 
              and real-time route management for the Delhi Transport Corporation.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/dashboard">
                <Button size="lg" className="bg-transit-orange hover:bg-orange-700 text-white">
                  View Dashboard
                </Button>
              </Link>
              <Link to="/contact">
                <Button size="lg" variant="outline" className="text-white border-white hover:bg-white/10">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
            <h3 className="text-xl font-semibold mb-6 text-center">Key Benefits</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="flex items-start space-x-4">
                <Clock className="h-8 w-8 text-transit-orange flex-shrink-0" />
                <div>
                  <h4 className="font-medium">Reduced Wait Times</h4>
                  <p className="text-blue-100 text-sm">Up to 40% reduction in passenger waiting times</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <TrendingUp className="h-8 w-8 text-transit-orange flex-shrink-0" />
                <div>
                  <h4 className="font-medium">Fuel Efficiency</h4>
                  <p className="text-blue-100 text-sm">15-25% improvement in fuel consumption</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <Bus className="h-8 w-8 text-transit-orange flex-shrink-0" />
                <div>
                  <h4 className="font-medium">Fleet Optimization</h4>
                  <p className="text-blue-100 text-sm">More efficient use of existing bus fleet</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <MapPin className="h-8 w-8 text-transit-orange flex-shrink-0" />
                <div>
                  <h4 className="font-medium">Live Tracking</h4>
                  <p className="text-blue-100 text-sm">Real-time location data for all buses</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;
