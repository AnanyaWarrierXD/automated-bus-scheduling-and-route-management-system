
import { useState } from 'react';
import { Server, Database, Smartphone, Bus, Cpu, Globe, ArrowRight } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';

const ArchitectureDiagram = () => {
  const [activeLayer, setActiveLayer] = useState<string | null>(null);
  
  const layers = [
    {
      id: 'data',
      title: 'Data Layer',
      icon: <Database className="h-8 w-8" />,
      color: 'bg-blue-100 text-blue-800',
      description: 'Stores and manages all system data including bus GPS coordinates, schedules, routes, and user feedback.',
      components: ['Real-time GPS Data', 'Historical Traffic Patterns', 'Passenger Count Records', 'Route Information', 'Schedule Database']
    },
    {
      id: 'processing',
      title: 'Processing Layer',
      icon: <Cpu className="h-8 w-8" />,
      color: 'bg-green-100 text-green-800',
      description: 'Performs computations for route optimization, schedule adjustments, and predictive analytics using AI algorithms.',
      components: ['Schedule Optimization Engine', 'Route Planning Algorithm', 'Traffic Prediction Model', 'Demand Forecasting System', 'Decision Support Engine']
    },
    {
      id: 'communication',
      title: 'Communication Layer',
      icon: <Globe className="h-8 w-8" />,
      color: 'bg-purple-100 text-purple-800',
      description: 'Enables secure data transfer between system components, buses, administrators, and passenger interfaces.',
      components: ['WebSocket Server', 'API Gateway', 'Notification System', 'Data Synchronization Service', 'Security Protocol Handler']
    },
    {
      id: 'presentation',
      title: 'Presentation Layer',
      icon: <Smartphone className="h-8 w-8" />,
      color: 'bg-orange-100 text-orange-800',
      description: 'Provides user interfaces for various stakeholders including administrators, drivers, and passengers.',
      components: ['Admin Dashboard', 'Driver Mobile App', 'Passenger Web Interface', 'Public Display Screens', 'Reporting Tools']
    },
    {
      id: 'hardware',
      title: 'Hardware Layer',
      icon: <Bus className="h-8 w-8" />,
      color: 'bg-red-100 text-red-800',
      description: 'Physical components including GPS devices on buses, traffic sensors, and server infrastructure.',
      components: ['Bus GPS Units', 'Passenger Counters', 'Traffic Sensors', 'Server Infrastructure', 'Network Hardware']
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">System Architecture</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            ABSRMS utilizes a multi-layered architecture to process data, optimize routes, and provide real-time updates.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="col-span-1">
            <div className="space-y-4">
              {layers.map((layer) => (
                <Button
                  key={layer.id}
                  variant={activeLayer === layer.id ? "default" : "outline"}
                  className={`w-full justify-start text-left ${activeLayer === layer.id ? "border-2 border-transit-blue" : ""}`}
                  onClick={() => setActiveLayer(layer.id)}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-full ${layer.color}`}>
                      {layer.icon}
                    </div>
                    <span>{layer.title}</span>
                  </div>
                </Button>
              ))}
            </div>
          </div>
          
          <div className="col-span-2">
            <Card className="h-full">
              <CardContent className="p-6">
                {activeLayer ? (
                  <div className="h-full flex flex-col">
                    {layers.find(l => l.id === activeLayer) && (
                      <>
                        <div className="mb-6">
                          <div className={`inline-flex p-3 rounded-full ${layers.find(l => l.id === activeLayer)?.color} mb-4`}>
                            {layers.find(l => l.id === activeLayer)?.icon}
                          </div>
                          <h3 className="text-2xl font-bold mb-2">{layers.find(l => l.id === activeLayer)?.title}</h3>
                          <p className="text-gray-600">{layers.find(l => l.id === activeLayer)?.description}</p>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                          {layers.find(l => l.id === activeLayer)?.components.map((component, index) => (
                            <div key={index} className="flex items-center space-x-2 p-3 bg-gray-50 rounded-md">
                              <ArrowRight className="h-4 w-4 text-transit-blue" />
                              <span>{component}</span>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                ) : (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8">
                    <Server className="h-16 w-16 text-gray-300 mb-4" />
                    <h3 className="text-xl font-medium text-gray-500 mb-2">Interactive Architecture Diagram</h3>
                    <p className="text-gray-400">Select a layer from the left to view its details and components</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ArchitectureDiagram;
