
import { Check, Clock } from 'lucide-react';

const ImplementationTimeline = () => {
  const phases = [
    {
      title: 'Phase 1: Planning & Analysis',
      status: 'completed',
      timeframe: 'Q1 2023',
      items: [
        'Requirements gathering from stakeholders',
        'System architecture design',
        'Technology stack selection',
        'Initial project planning and resource allocation',
        'Budget approval and project kickoff'
      ]
    },
    {
      title: 'Phase 2: Development & Testing',
      status: 'completed',
      timeframe: 'Q2-Q3 2023',
      items: [
        'Core system development',
        'GPS tracking implementation',
        'Database design and setup',
        'Admin dashboard creation',
        'Integration testing and quality assurance'
      ]
    },
    {
      title: 'Phase 3: Pilot Deployment',
      status: 'active',
      timeframe: 'Q4 2023 - Q1 2024',
      items: [
        'Deployment on selected routes',
        'Driver and staff training',
        'System performance monitoring',
        'User feedback collection',
        'Iterative improvements based on pilot results'
      ]
    },
    {
      title: 'Phase 4: Full Implementation',
      status: 'upcoming',
      timeframe: 'Q2-Q3 2024',
      items: [
        'System-wide rollout across all DTC routes',
        'Integration with passenger information systems',
        'Public launch of mobile applications',
        'Comprehensive performance monitoring',
        'Continuous optimization and updates'
      ]
    },
    {
      title: 'Phase 5: Expansion & Enhancement',
      status: 'upcoming',
      timeframe: 'Q4 2024 onwards',
      items: [
        'Feature enhancements based on collected data',
        'Integration with other transit systems',
        'Advanced analytics implementation',
        'Expansion to neighboring regions',
        'Research for next-generation improvements'
      ]
    }
  ];

  const getStatusClasses = (status: string) => {
    switch(status) {
      case 'completed':
        return {
          dot: 'bg-green-500 border-green-500',
          text: 'text-green-500',
          line: 'border-green-500'
        };
      case 'active':
        return {
          dot: 'bg-blue-500 border-blue-500',
          text: 'text-blue-500',
          line: 'border-blue-500'
        };
      case 'upcoming':
        return {
          dot: 'bg-white border-gray-300',
          text: 'text-gray-500',
          line: 'border-gray-300'
        };
      default:
        return {
          dot: 'bg-white border-gray-300',
          text: 'text-gray-500',
          line: 'border-gray-300'
        };
    }
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Implementation Timeline</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            The ABSRMS project is being implemented in phases to ensure smooth adoption and optimal performance.
          </p>
        </div>
        
        <div className="relative">
          {phases.map((phase, index) => {
            const statusClasses = getStatusClasses(phase.status);
            const isLast = index === phases.length - 1;
            
            return (
              <div key={index} className="relative pl-8 pb-10 md:pl-0">
                <div className="md:grid md:grid-cols-5 items-start">
                  <div className="md:col-span-1 mb-4 md:mb-0 md:text-right md:pr-8">
                    <div className="text-sm font-semibold text-gray-500">{phase.timeframe}</div>
                    <div className={`text-lg font-bold ${statusClasses.text} mt-1`}>
                      {phase.status === 'completed' ? 'Completed' : 
                       phase.status === 'active' ? 'In Progress' : 'Upcoming'}
                    </div>
                  </div>
                  
                  {/* Timeline line and dot */}
                  <div className="absolute left-0 top-0 md:left-auto md:right-auto md:top-2 md:inset-x-1/2 flex items-center justify-center">
                    <div className={`w-6 h-6 rounded-full border-2 ${statusClasses.dot} z-10 flex items-center justify-center`}>
                      {phase.status === 'completed' && <Check className="h-3 w-3 text-white" />}
                      {phase.status === 'active' && <Clock className="h-3 w-3 text-white" />}
                    </div>
                    {!isLast && (
                      <div className={`absolute h-full w-0 border-l-2 ${statusClasses.line} z-0 top-6 bottom-0 left-3 md:left-auto md:top-6`} style={{ height: 'calc(100% + 20px)' }}></div>
                    )}
                  </div>
                  
                  <div className="md:col-span-4 md:pl-8">
                    <div className={`bg-white rounded-lg shadow-sm p-6 border-l-4 ${
                      phase.status === 'completed' ? 'border-green-500' : 
                      phase.status === 'active' ? 'border-blue-500' : 'border-gray-300'
                    }`}>
                      <h3 className="text-xl font-bold mb-4">{phase.title}</h3>
                      <ul className="space-y-2">
                        {phase.items.map((item, idx) => (
                          <li key={idx} className="flex items-start">
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center mt-0.5 mr-3 flex-shrink-0 ${
                              phase.status === 'completed' ? 'bg-green-100 text-green-600' : 
                              phase.status === 'active' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-400'
                            }`}>
                              {phase.status === 'completed' ? (
                                <Check className="h-3 w-3" />
                              ) : (
                                <div className="w-1.5 h-1.5 rounded-full bg-current"></div>
                              )}
                            </div>
                            <span className={phase.status === 'upcoming' ? 'text-gray-500' : 'text-gray-700'}>
                              {item}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ImplementationTimeline;
