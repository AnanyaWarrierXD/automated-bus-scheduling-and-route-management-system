
import { Lightbulb, Users, Map, Clock } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

const AbstractSection = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Abstract & Introduction</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Delhi's public transportation system faces significant challenges with manual scheduling and inefficient route planning. ABSRMS provides an intelligent solution.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4 text-transit-blue">The Problem</h3>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                <span>Inefficient manual scheduling leading to buses clustering on profitable routes</span>
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                <span>Lack of real-time data for making dynamic scheduling decisions</span>
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                <span>Long waiting times for passengers due to unpredictable arrival times</span>
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                <span>Wasted fuel and resources due to suboptimal route planning</span>
              </li>
              <li className="flex items-start">
                <span className="text-red-500 mr-2">•</span>
                <span>Difficulty in adjusting service to match changing demand patterns</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold mb-4 text-transit-green">Our Solution</h3>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                <span>Automated scheduling system using AI algorithms to optimize bus deployment</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                <span>Real-time GPS tracking to provide accurate location data of all buses</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                <span>Dynamic route adjustments based on current traffic and passenger demand</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                <span>Predictive analytics to anticipate and respond to peak travel times</span>
              </li>
              <li className="flex items-start">
                <span className="text-green-500 mr-2">•</span>
                <span>User-friendly interface for both transit administrators and passengers</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <Lightbulb className="h-8 w-8 text-transit-blue mb-2" />
              <CardTitle>Smart Allocation</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                AI-driven algorithms analyze historical and real-time data to optimize bus allocation across routes.
              </CardDescription>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <Users className="h-8 w-8 text-transit-blue mb-2" />
              <CardTitle>Passenger Focused</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                System prioritizes reducing wait times and improving overall passenger experience.
              </CardDescription>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <Map className="h-8 w-8 text-transit-blue mb-2" />
              <CardTitle>Dynamic Routing</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Routes adapt to traffic conditions and changing passenger demands throughout the day.
              </CardDescription>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <Clock className="h-8 w-8 text-transit-blue mb-2" />
              <CardTitle>Real-time Updates</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Live information sharing between buses, control center, and passenger information systems.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default AbstractSection;
