
import { MapPin, Clock, TrendingUp, BarChart4, Zap, AlertCircle, RotateCw, Radio } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

const FeaturesSection = () => {
  return (
    <section className="py-16 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Key Features</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            ABSRMS offers a comprehensive suite of features designed to revolutionize public transportation management.
          </p>
        </div>
        
        <Tabs defaultValue="tracking" className="w-full">
          <TabsList className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 h-auto mb-8">
            <TabsTrigger value="tracking" className="py-3">
              <div className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" /> GPS Tracking
              </div>
            </TabsTrigger>
            <TabsTrigger value="scheduling" className="py-3">
              <div className="flex items-center">
                <Clock className="h-5 w-5 mr-2" /> Dynamic Scheduling
              </div>
            </TabsTrigger>
            <TabsTrigger value="optimization" className="py-3">
              <div className="flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" /> Route Optimization
              </div>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="py-3">
              <div className="flex items-center">
                <BarChart4 className="h-5 w-5 mr-2" /> Advanced Analytics
              </div>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="tracking" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <div className="bg-blue-50 p-6 rounded-lg h-full">
                  <MapPin className="h-10 w-10 text-transit-blue mb-4" />
                  <h3 className="text-xl font-bold mb-4">Real-time GPS Tracking</h3>
                  <p className="text-gray-700 mb-6">
                    Every bus in the fleet is equipped with GPS technology, enabling real-time location tracking
                    accurate to within 3 meters. This data forms the foundation of the entire system.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-green mt-0.5 mr-2" />
                      <span>Live position updates every 10 seconds</span>
                    </li>
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-green mt-0.5 mr-2" />
                      <span>Automatic geofencing for route adherence</span>
                    </li>
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-green mt-0.5 mr-2" />
                      <span>Historical path recording for analysis</span>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="lg:col-span-2 flex items-center justify-center">
                <div className="bg-white p-4 rounded-lg shadow-md w-full max-w-3xl">
                  <div className="relative aspect-video rounded-md overflow-hidden border border-gray-200">
                    <div className="absolute inset-0 bg-gray-100">
                      {/* This would be replaced with an actual map or visualization */}
                      <div className="absolute inset-0 bg-gray-200 opacity-50">
                        <div className="grid grid-cols-12 grid-rows-12 h-full w-full">
                          {[...Array(144)].map((_, idx) => (
                            <div key={idx} className="border border-gray-300 opacity-30"></div>
                          ))}
                        </div>
                      </div>
                      
                      {/* Simulate bus routes */}
                      <div className="absolute inset-0">
                        <div className="absolute top-1/4 left-1/4 right-1/4 h-1 bg-blue-500 opacity-70 rounded"></div>
                        <div className="absolute top-1/2 left-1/3 right-1/6 h-1 bg-green-500 opacity-70 rounded"></div>
                        <div className="absolute top-3/4 left-1/6 right-1/3 h-1 bg-red-500 opacity-70 rounded"></div>
                        
                        {/* Simulate buses */}
                        <div className="absolute top-1/4 left-1/3 w-3 h-3 bg-blue-600 rounded-full"></div>
                        <div className="absolute top-1/4 left-2/3 w-3 h-3 bg-blue-600 rounded-full animate-pulse"></div>
                        <div className="absolute top-1/2 left-1/2 w-3 h-3 bg-green-600 rounded-full"></div>
                        <div className="absolute top-3/4 left-1/4 w-3 h-3 bg-red-600 rounded-full animate-pulse"></div>
                      </div>
                      
                      <div className="absolute bottom-4 right-4 bg-white p-2 rounded shadow-md">
                        <div className="text-xs font-medium">Live Tracking Demo</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="scheduling" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <div className="bg-green-50 p-6 rounded-lg h-full">
                  <Clock className="h-10 w-10 text-transit-green mb-4" />
                  <h3 className="text-xl font-bold mb-4">Dynamic Scheduling</h3>
                  <p className="text-gray-700 mb-6">
                    Traditional static schedules are replaced with AI-powered dynamic scheduling that adapts to 
                    real-world conditions, passenger demand, and traffic situations in real-time.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-green mt-0.5 mr-2" />
                      <span>Automatic schedule adjustments based on demand</span>
                    </li>
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-green mt-0.5 mr-2" />
                      <span>Rush hour optimization with reinforcement learning</span>
                    </li>
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-green mt-0.5 mr-2" />
                      <span>Special event handling and contingency planning</span>
                    </li>
                  </ul>
                </div>
              </div>
              
              <div className="lg:col-span-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 h-full">
                  <Card>
                    <CardHeader className="pb-2">
                      <Zap className="h-6 w-6 text-yellow-500 mb-2" />
                      <CardTitle className="text-lg">Responsive Timetables</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">
                        Schedules automatically adjust based on real-time conditions, reducing bunching and ensuring even coverage across routes.
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <AlertCircle className="h-6 w-6 text-red-500 mb-2" />
                      <CardTitle className="text-lg">Disruption Management</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">
                        System detects and responds to disruptions like traffic incidents, breakdowns, or unexpected crowds with minimal delay.
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <RotateCw className="h-6 w-6 text-blue-500 mb-2" />
                      <CardTitle className="text-lg">Continuous Learning</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">
                        AI algorithms improve over time by analyzing performance data and passenger feedback to refine scheduling decisions.
                      </p>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader className="pb-2">
                      <TrendingUp className="h-6 w-6 text-green-500 mb-2" />
                      <CardTitle className="text-lg">Demand Prediction</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">
                        Forecasts passenger loads based on historical patterns, weather, local events, and other relevant factors.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="optimization" className="mt-0">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="p-6 bg-orange-50 rounded-lg">
                <TrendingUp className="h-10 w-10 text-transit-orange mb-4" />
                <h3 className="text-xl font-bold mb-4">Route Optimization</h3>
                <p className="text-gray-700 mb-6">
                  Advanced algorithms analyze multiple data points to create optimal routes that reduce travel times,
                  minimize fuel consumption, and maximize passenger service.
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-lg">
                    <h4 className="font-medium text-transit-orange mb-2">Traffic-Aware Routing</h4>
                    <p className="text-sm text-gray-600">
                      Routes dynamically adjust based on current traffic conditions to avoid congestion and delays.
                    </p>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg">
                    <h4 className="font-medium text-transit-orange mb-2">Historical Pattern Analysis</h4>
                    <p className="text-sm text-gray-600">
                      System learns from past traffic patterns to predict and avoid recurring congestion points.
                    </p>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg">
                    <h4 className="font-medium text-transit-orange mb-2">Multi-objective Optimization</h4>
                    <p className="text-sm text-gray-600">
                      Balances multiple factors including travel time, passenger volume, and operational costs.
                    </p>
                  </div>
                  
                  <div className="bg-white p-4 rounded-lg">
                    <h4 className="font-medium text-transit-orange mb-2">Constraint Handling</h4>
                    <p className="text-sm text-gray-600">
                      Accounts for physical limitations, regulatory requirements, and driver shift regulations.
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="p-6 bg-white border border-gray-200 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold mb-4">Route Optimization Benefits</h3>
                
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Fuel Efficiency</span>
                      <span className="text-sm font-medium text-transit-green">+18%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-transit-green h-2.5 rounded-full" style={{ width: '78%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Travel Time Reduction</span>
                      <span className="text-sm font-medium text-transit-blue">-22%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-transit-blue h-2.5 rounded-full" style={{ width: '82%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Passenger Satisfaction</span>
                      <span className="text-sm font-medium text-transit-orange">+35%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-transit-orange h-2.5 rounded-full" style={{ width: '85%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Route Coverage</span>
                      <span className="text-sm font-medium text-purple-600">+15%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: '65%' }}></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Carbon Emission Reduction</span>
                      <span className="text-sm font-medium text-emerald-600">-24%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2.5">
                      <div className="bg-emerald-600 h-2.5 rounded-full" style={{ width: '74%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="analytics" className="mt-0">
            <div className="bg-blue-50 p-6 rounded-lg">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div>
                  <BarChart4 className="h-10 w-10 text-transit-blue mb-4" />
                  <h3 className="text-xl font-bold mb-4">Advanced Analytics</h3>
                  <p className="text-gray-700 mb-6">
                    Comprehensive data analysis tools that convert raw transit data into actionable insights 
                    for continuous system improvement and strategic planning.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-blue mt-0.5 mr-2" />
                      <span>Passenger flow analysis across routes and times</span>
                    </li>
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-blue mt-0.5 mr-2" />
                      <span>Performance metrics with custom KPI tracking</span>
                    </li>
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-blue mt-0.5 mr-2" />
                      <span>Predictive maintenance based on vehicle telemetry</span>
                    </li>
                    <li className="flex items-start">
                      <Radio className="h-5 w-5 text-transit-blue mt-0.5 mr-2" />
                      <span>Long-term trend identification for planning</span>
                    </li>
                  </ul>
                </div>
                
                <div className="lg:col-span-2">
                  <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 h-full">
                    <h4 className="text-lg font-medium mb-4">Sample Analytics Dashboard</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                      <div className="bg-gray-50 p-4 rounded-md">
                        <div className="text-sm text-gray-500 mb-1">Daily Ridership</div>
                        <div className="text-2xl font-bold text-transit-blue">187,432</div>
                        <div className="text-xs text-green-600 flex items-center">
                          <TrendingUp className="h-3 w-3 mr-1" /> +3.2% from last week
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-4 rounded-md">
                        <div className="text-sm text-gray-500 mb-1">On-Time Performance</div>
                        <div className="text-2xl font-bold text-transit-green">92.7%</div>
                        <div className="text-xs text-green-600 flex items-center">
                          <TrendingUp className="h-3 w-3 mr-1" /> +5.4% from last month
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-4 rounded-md mb-4">
                      <div className="text-sm font-medium mb-2">Hourly Passenger Distribution</div>
                      <div className="h-24 flex items-end space-x-2">
                        {[15, 12, 10, 18, 30, 45, 60, 70, 65, 40, 45, 50, 55, 65, 60, 50, 40, 55, 30, 25, 20, 15, 10, 5].map((value, idx) => (
                          <div 
                            key={idx} 
                            className="bg-blue-500 w-full rounded-t"
                            style={{ height: `${value}%` }}
                          ></div>
                        ))}
                      </div>
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>12am</span>
                        <span>6am</span>
                        <span>12pm</span>
                        <span>6pm</span>
                        <span>12am</span>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div className="bg-gray-50 p-3 rounded-md">
                        <div className="text-xs text-gray-500 mb-1">Most Active Route</div>
                        <div className="text-sm font-bold">Route 38</div>
                        <div className="text-xs text-gray-600">Connaught Place - Nehru Place</div>
                      </div>
                      
                      <div className="bg-gray-50 p-3 rounded-md">
                        <div className="text-xs text-gray-500 mb-1">Average Wait Time</div>
                        <div className="text-sm font-bold">8.2 min</div>
                        <div className="text-xs text-green-600">-1.7 min improvement</div>
                      </div>
                      
                      <div className="bg-gray-50 p-3 rounded-md">
                        <div className="text-xs text-gray-500 mb-1">Fuel Efficiency</div>
                        <div className="text-sm font-bold">5.2 km/L</div>
                        <div className="text-xs text-green-600">+0.8 km/L improvement</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};

export default FeaturesSection;
