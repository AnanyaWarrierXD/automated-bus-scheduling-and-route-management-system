
import { CheckCircle2 } from 'lucide-react';

const SdgContribution = () => {
  const contributionPoints = [
    {
      title: 'Infrastructure Enhancement',
      description: 'Modernizes Delhi\'s transport infrastructure with smart technology integration and data-driven optimization.',
      icon: <img src="https://placehold.co/48x48/FFFFFF/1976D2?text=9.1" alt="SDG 9.1" className="rounded" />
    },
    {
      title: 'Sustainable Public Transport',
      description: 'Promotes affordable, sustainable, and efficient public transportation access for all Delhi residents.',
      icon: <img src="https://placehold.co/48x48/FFFFFF/1976D2?text=9.4" alt="SDG 9.4" className="rounded" />
    },
    {
      title: 'Innovation in Urban Mobility',
      description: 'Applies advanced AI algorithms and predictive analytics to solve real-world transportation challenges.',
      icon: <img src="https://placehold.co/48x48/FFFFFF/1976D2?text=9.5" alt="SDG 9.5" className="rounded" />
    },
    {
      title: 'Resource Efficiency',
      description: 'Optimizes fleet usage and reduces fuel consumption, promoting resource-efficient transport solutions.',
      icon: <img src="https://placehold.co/48x48/FFFFFF/00796B?text=12.2" alt="SDG 12.2" className="rounded" />
    },
    {
      title: 'Emissions Reduction',
      description: 'Minimizes idle time and optimizes routes to reduce carbon emissions from the public bus fleet.',
      icon: <img src="https://placehold.co/48x48/FFFFFF/4CAF50?text=13.2" alt="SDG 13.2" className="rounded" />
    },
    {
      title: 'Quality of Life Improvement',
      description: 'Enhances commuter experience with reduced waiting times and more reliable public transportation.',
      icon: <img src="https://placehold.co/48x48/FFFFFF/FF9800?text=11.2" alt="SDG 11.2" className="rounded" />
    },
  ];

  return (
    <section className="py-16 bg-blue-900 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">SDG Contribution</h2>
          <p className="text-lg text-blue-100 max-w-3xl mx-auto">
            ABSRMS strongly aligns with UN Sustainable Development Goal 9: Industry, Innovation, and Infrastructure, 
            while also supporting several other SDGs.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row items-center justify-center mb-12">
          <div className="rounded-lg overflow-hidden mb-8 md:mb-0 md:mr-10">
            <img 
              src="https://placehold.co/300x300/1976D2/FFFFFF?text=SDG+9" 
              alt="SDG 9: Industry, Innovation, and Infrastructure" 
              className="w-[200px] h-[200px] object-cover"
            />
          </div>
          
          <div className="max-w-2xl">
            <h3 className="text-2xl font-bold mb-4">Primary Focus: SDG 9</h3>
            <p className="text-lg mb-4">
              Build resilient infrastructure, promote inclusive and sustainable industrialization, and foster innovation.
            </p>
            <p className="text-blue-100">
              ABSRMS exemplifies how smart technology and data-driven approaches can transform traditional infrastructure into more 
              efficient, sustainable systems. By implementing advanced scheduling algorithms and real-time monitoring, we're creating 
              resilient transit infrastructure that adapts to urban challenges and provides reliable service for all.
            </p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {contributionPoints.map((point, index) => (
            <div key={index} className="bg-blue-800 rounded-lg p-6 border border-blue-700 hover:bg-blue-700 transition-colors">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  {point.icon}
                </div>
                <div>
                  <h4 className="text-lg font-semibold mb-2">{point.title}</h4>
                  <p className="text-blue-100">{point.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-gradient-to-r from-blue-800 to-blue-700 rounded-lg p-6">
          <h3 className="text-xl font-bold mb-4">Additional SDG Impacts</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="flex items-center space-x-3">
              <CheckCircle2 className="h-5 w-5 text-green-400" />
              <span>SDG 11: Sustainable Cities and Communities</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle2 className="h-5 w-5 text-green-400" />
              <span>SDG 12: Responsible Consumption and Production</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle2 className="h-5 w-5 text-green-400" />
              <span>SDG 13: Climate Action</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle2 className="h-5 w-5 text-green-400" />
              <span>SDG 7: Affordable and Clean Energy</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle2 className="h-5 w-5 text-green-400" />
              <span>SDG 8: Decent Work and Economic Growth</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle2 className="h-5 w-5 text-green-400" />
              <span>SDG 3: Good Health and Well-being</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SdgContribution;
