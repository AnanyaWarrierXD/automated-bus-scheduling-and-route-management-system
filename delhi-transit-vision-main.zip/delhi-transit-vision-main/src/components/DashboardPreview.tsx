
import { useState } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, ResponsiveContainer, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Clock, Users, TrendingDown, Fuel, MapPin, Bus } from 'lucide-react';

const DashboardPreview = () => {
  const [activeTab, setActiveTab] = useState('metrics');

  const waitTimeData = [
    { month: 'Jan', before: 18, after: 12 },
    { month: 'Feb', before: 19, after: 11 },
    { month: 'Mar', before: 17, after: 10 },
    { month: 'Apr', before: 20, after: 9 },
    { month: 'May', before: 18, after: 8 },
    { month: 'Jun', before: 16, after: 8 },
    { month: 'Jul', before: 15, after: 7 },
    { month: 'Aug', before: 14, after: 7 },
  ];

  const fuelData = [
    { route: 'Route 34', before: 3.8, after: 4.9 },
    { route: 'Route 38', before: 4.1, after: 5.2 },
    { route: 'Route 45', before: 3.5, after: 4.7 },
    { route: 'Route 72', before: 3.9, after: 5.0 },
    { route: 'Route 56', before: 4.2, after: 5.5 },
    { route: 'Route 29', before: 3.7, after: 4.8 },
  ];

  const routeDistributionData = [
    { name: 'North Delhi', value: 35 },
    { name: 'South Delhi', value: 30 },
    { name: 'East Delhi', value: 15 },
    { name: 'West Delhi', value: 20 },
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  const metricsData = [
    {
      title: 'Average Wait Time',
      icon: <Clock className="h-8 w-8 text-blue-500" />,
      value: '7.5 min',
      change: '-43%',
      changeType: 'positive',
      description: 'Reduced from 13.2 minutes before implementation'
    },
    {
      title: 'Daily Ridership',
      icon: <Users className="h-8 w-8 text-green-500" />,
      value: '176,450',
      change: '+12%',
      changeType: 'positive',
      description: 'Increased from 157,500 passengers per day'
    },
    {
      title: 'Service Delays',
      icon: <TrendingDown className="h-8 w-8 text-orange-500" />,
      value: '38 min',
      change: '-62%',
      changeType: 'positive',
      description: 'Reduced from 100 minutes average delay per day'
    },
    {
      title: 'Fuel Efficiency',
      icon: <Fuel className="h-8 w-8 text-purple-500" />,
      value: '5.1 km/L',
      change: '+24%',
      changeType: 'positive',
      description: 'Improved from 4.1 km/L average consumption'
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Dashboard Preview</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Explore a preview of the ABSRMS administrative dashboard showing key performance metrics and system benefits.
          </p>
        </div>
        
        <div className="bg-gray-100 rounded-xl p-6 md:p-8 shadow-md">
          <div className="flex justify-between items-center mb-8">
            <div className="flex items-center space-x-2">
              <Bus className="h-6 w-6 text-transit-blue" />
              <h3 className="text-xl font-bold">ABSRMS Admin Dashboard</h3>
            </div>
            <div className="text-sm text-gray-500">Last updated: Today, 10:45 AM</div>
          </div>
          
          <Tabs defaultValue="metrics" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-8">
              <TabsTrigger value="metrics">Key Metrics</TabsTrigger>
              <TabsTrigger value="wait-time">Wait Time Analysis</TabsTrigger>
              <TabsTrigger value="fuel">Fuel Efficiency</TabsTrigger>
              <TabsTrigger value="coverage">Route Coverage</TabsTrigger>
            </TabsList>
            
            <TabsContent value="metrics">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {metricsData.map((metric, index) => (
                  <Card key={index}>
                    <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
                      <CardTitle className="text-sm font-medium">{metric.title}</CardTitle>
                      {metric.icon}
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{metric.value}</div>
                      <div className={`flex items-center text-xs ${
                        metric.changeType === 'positive' ? 'text-green-500' : 'text-red-500'
                      }`}>
                        {metric.change}
                        <span className="ml-1">since implementation</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">{metric.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Live Fleet Status</CardTitle>
                  <CardDescription>Real-time status of buses across Delhi</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    <div className="bg-green-50 p-4 rounded-lg flex justify-between items-center">
                      <div>
                        <div className="text-sm text-gray-500">On Route</div>
                        <div className="text-2xl font-bold text-green-600">482</div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                        <Bus className="h-5 w-5 text-green-600" />
                      </div>
                    </div>
                    
                    <div className="bg-blue-50 p-4 rounded-lg flex justify-between items-center">
                      <div>
                        <div className="text-sm text-gray-500">At Depot</div>
                        <div className="text-2xl font-bold text-blue-600">156</div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <MapPin className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                    
                    <div className="bg-orange-50 p-4 rounded-lg flex justify-between items-center">
                      <div>
                        <div className="text-sm text-gray-500">Maintenance</div>
                        <div className="text-2xl font-bold text-orange-600">37</div>
                      </div>
                      <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="wait-time">
              <Card>
                <CardHeader>
                  <CardTitle>Wait Time Reduction</CardTitle>
                  <CardDescription>Average passenger wait times before and after ABSRMS implementation</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        width={500}
                        height={300}
                        data={waitTimeData}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="month" />
                        <YAxis label={{ value: 'Minutes', angle: -90, position: 'insideLeft' }} />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="before" stroke="#ff7300" name="Before ABSRMS" activeDot={{ r: 8 }} />
                        <Line type="monotone" dataKey="after" stroke="#0088FE" name="After ABSRMS" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-6">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Peak Wait Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">42% ↓</div>
                    <p className="text-xs text-muted-foreground">Reduction during rush hours</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Weekend Wait Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">38% ↓</div>
                    <p className="text-xs text-muted-foreground">Improvement on weekends</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium">Off-Peak Wait Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">45% ↓</div>
                    <p className="text-xs text-muted-foreground">Reduction during off-peak hours</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="fuel">
              <Card>
                <CardHeader>
                  <CardTitle>Fuel Efficiency Improvement</CardTitle>
                  <CardDescription>Fuel consumption in kilometers per liter by route (before vs. after)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        width={500}
                        height={300}
                        data={fuelData}
                        margin={{
                          top: 5,
                          right: 30,
                          left: 20,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="route" />
                        <YAxis label={{ value: 'km/L', angle: -90, position: 'insideLeft' }} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="before" name="Before ABSRMS" fill="#8884d8" />
                        <Bar dataKey="after" name="After ABSRMS" fill="#82ca9d" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Environmental Impact</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-500 mb-1">CO₂ Reduction</div>
                      <div className="text-2xl font-bold text-green-600">286 tons</div>
                      <div className="text-xs text-green-700">Monthly reduction</div>
                    </div>
                    
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-500 mb-1">Fuel Saved</div>
                      <div className="text-2xl font-bold text-blue-600">124,500 L</div>
                      <div className="text-xs text-blue-700">Monthly savings</div>
                    </div>
                    
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <div className="text-sm text-gray-500 mb-1">Cost Savings</div>
                      <div className="text-2xl font-bold text-orange-600">₹ 1.2 Cr</div>
                      <div className="text-xs text-orange-700">Monthly fuel cost reduction</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="coverage">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Route Distribution</CardTitle>
                    <CardDescription>Distribution of buses by region</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="h-72">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart width={400} height={400}>
                          <Pie
                            data={routeDistributionData}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                            outerRadius={80}
                            fill="#8884d8"
                            dataKey="value"
                          >
                            {routeDistributionData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                          </Pie>
                          <Tooltip />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Coverage Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Service Area Coverage</span>
                          <span className="text-sm font-medium text-green-600">92%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-green-600 h-2.5 rounded-full" style={{ width: '92%' }}></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Bus Stop Accessibility</span>
                          <span className="text-sm font-medium text-blue-600">88%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: '88%' }}></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Route Reliability</span>
                          <span className="text-sm font-medium text-purple-600">94%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-purple-600 h-2.5 rounded-full" style={{ width: '94%' }}></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Schedule Adherence</span>
                          <span className="text-sm font-medium text-orange-600">87%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-orange-600 h-2.5 rounded-full" style={{ width: '87%' }}></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">Population Served</span>
                          <span className="text-sm font-medium text-teal-600">84%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className="bg-teal-600 h-2.5 rounded-full" style={{ width: '84%' }}></div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  );
};

export default DashboardPreview;
