
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation } from '@tanstack/react-query';
import { fetchFeedback, updateFeedbackStatus, isAuthenticated, login, logout, FeedbackData } from '@/services/api';
import { toast } from 'sonner';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { CheckCircle, Clock, AlertCircle, Search, Mail, Calendar, User, FileText, LogOut } from 'lucide-react';
import { Label } from '@/components/ui/label';

const Admin = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  // Check authentication status on component mount
  useEffect(() => {
    setIsLoggedIn(isAuthenticated());
  }, []);

  // Fetch feedback data if authenticated
  const { 
    data: feedbackData, 
    isLoading, 
    error, 
    refetch 
  } = useQuery({
    queryKey: ['feedback'],
    queryFn: fetchFeedback,
    enabled: isLoggedIn
  });

  // Update feedback status mutation
  const updateStatusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string, status: 'pending' | 'reviewed' | 'resolved' }) => 
      updateFeedbackStatus(id, status),
    onSuccess: () => {
      toast.success('Feedback status updated successfully');
      refetch();
    },
    onError: () => {
      toast.error('Failed to update status. Please try again.');
    }
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const success = await login(username, password);
    if (success) {
      setIsLoggedIn(true);
      toast.success('Logged in successfully');
    }
  };

  const handleLogout = () => {
    logout();
    setIsLoggedIn(false);
    toast.success('Logged out successfully');
  };

  // Filter feedback based on search term
  const filteredFeedback = feedbackData?.filter((feedback) => 
    feedback.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    feedback.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    feedback.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
    feedback.feedbackType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Group feedback by status
  const pendingFeedback = filteredFeedback?.filter((item) => item.status === 'pending');
  const reviewedFeedback = filteredFeedback?.filter((item) => item.status === 'reviewed');
  const resolvedFeedback = filteredFeedback?.filter((item) => item.status === 'resolved');

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 flex items-center justify-center bg-gray-50">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Admin Login</CardTitle>
              <CardDescription>
                Sign in to access the admin dashboard for ABSRMS
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    placeholder="Enter your username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full">Login</Button>
              </form>
            </CardContent>
            <CardFooter className="text-sm text-gray-500 text-center">
              <p>For demo purposes, use: <strong>admin</strong> / <strong>admin123</strong></p>
            </CardFooter>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="bg-gray-100 py-8">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <div>
                <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
                <p className="text-gray-600">
                  Manage feedback and system performance from a central location.
                </p>
              </div>
              <Button variant="outline" onClick={handleLogout} className="flex items-center">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Total Feedback</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{feedbackData?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">Across all categories</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Pending Review</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{pendingFeedback?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">Awaiting administrator action</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Resolution Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {feedbackData?.length ? 
                      Math.round((resolvedFeedback?.length || 0) / feedbackData.length * 100) : 0}%
                  </div>
                  <p className="text-xs text-muted-foreground">Successfully resolved feedback</p>
                </CardContent>
              </Card>
            </div>
            
            <div className="bg-white rounded-lg shadow-md p-6 mb-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold">Feedback Management</h2>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                  <Input
                    type="text"
                    placeholder="Search feedback..."
                    className="pl-10 w-64"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
              
              <Tabs defaultValue="pending">
                <TabsList className="mb-6">
                  <TabsTrigger value="pending" className="flex items-center">
                    <Clock className="h-4 w-4 mr-2" />
                    Pending ({pendingFeedback?.length || 0})
                  </TabsTrigger>
                  <TabsTrigger value="reviewed" className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Reviewed ({reviewedFeedback?.length || 0})
                  </TabsTrigger>
                  <TabsTrigger value="resolved" className="flex items-center">
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Resolved ({resolvedFeedback?.length || 0})
                  </TabsTrigger>
                  <TabsTrigger value="all">All Feedback</TabsTrigger>
                </TabsList>
                
                <TabsContent value="pending">
                  <FeedbackList 
                    feedbackItems={pendingFeedback || []} 
                    isLoading={isLoading} 
                    updateStatus={(id, status) => updateStatusMutation.mutate({ id, status })}
                  />
                </TabsContent>
                
                <TabsContent value="reviewed">
                  <FeedbackList 
                    feedbackItems={reviewedFeedback || []} 
                    isLoading={isLoading} 
                    updateStatus={(id, status) => updateStatusMutation.mutate({ id, status })}
                  />
                </TabsContent>
                
                <TabsContent value="resolved">
                  <FeedbackList 
                    feedbackItems={resolvedFeedback || []} 
                    isLoading={isLoading} 
                    updateStatus={(id, status) => updateStatusMutation.mutate({ id, status })}
                  />
                </TabsContent>
                
                <TabsContent value="all">
                  <FeedbackList 
                    feedbackItems={filteredFeedback || []} 
                    isLoading={isLoading} 
                    updateStatus={(id, status) => updateStatusMutation.mutate({ id, status })}
                  />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

interface FeedbackListProps {
  feedbackItems: FeedbackData[];
  isLoading: boolean;
  updateStatus: (id: string, status: 'pending' | 'reviewed' | 'resolved') => void;
}

const FeedbackList = ({ feedbackItems, isLoading, updateStatus }: FeedbackListProps) => {
  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800 mb-4"></div>
        <p>Loading feedback data...</p>
      </div>
    );
  }

  if (feedbackItems.length === 0) {
    return (
      <div className="text-center py-12 bg-gray-50 rounded-lg">
        <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-500">No feedback found</p>
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'pending':
        return <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs flex items-center">
          <Clock className="h-3 w-3 mr-1" /> Pending
        </span>;
      case 'reviewed':
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-xs flex items-center">
          <CheckCircle className="h-3 w-3 mr-1" /> Reviewed
        </span>;
      case 'resolved':
        return <span className="px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs flex items-center">
          <CheckCircle className="h-3 w-3 mr-1" /> Resolved
        </span>;
      default:
        return null;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getTypeColor = (type: string) => {
    switch(type) {
      case 'suggestion': return 'bg-blue-100 text-blue-800';
      case 'issue': return 'bg-red-100 text-red-800';
      case 'general': return 'bg-green-100 text-green-800';
      case 'partnership': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-4">
      {feedbackItems.map((feedback) => (
        <Card key={feedback.id} className="border-l-4 border-l-gray-300">
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="flex items-center text-lg">
                  <User className="h-4 w-4 mr-2" />
                  {feedback.name}
                </CardTitle>
                <CardDescription className="flex items-center">
                  <Mail className="h-3 w-3 mr-1" /> {feedback.email}
                  {feedback.phone && <span className="ml-4">{feedback.phone}</span>}
                </CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                {getStatusBadge(feedback.status)}
                <span className={`px-2 py-1 rounded-full text-xs ${getTypeColor(feedback.feedbackType)}`}>
                  {feedback.feedbackType.charAt(0).toUpperCase() + feedback.feedbackType.slice(1)}
                </span>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-md my-2">
              <p className="text-gray-700">{feedback.message}</p>
            </div>
            <div className="text-xs text-gray-500 flex items-center mt-2">
              <Calendar className="h-3 w-3 mr-1" />
              Submitted on {formatDate(feedback.createdAt)}
            </div>
          </CardContent>
          <CardFooter className="flex justify-end gap-2 pt-0">
            {feedback.status === 'pending' && (
              <>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => updateStatus(feedback.id, 'reviewed')}
                >
                  Mark as Reviewed
                </Button>
                <Button 
                  variant="default" 
                  size="sm"
                  onClick={() => updateStatus(feedback.id, 'resolved')}
                >
                  Resolve
                </Button>
              </>
            )}
            {feedback.status === 'reviewed' && (
              <Button 
                variant="default" 
                size="sm"
                onClick={() => updateStatus(feedback.id, 'resolved')}
              >
                Resolve
              </Button>
            )}
            {feedback.status === 'resolved' && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => updateStatus(feedback.id, 'pending')}
              >
                Reopen
              </Button>
            )}
          </CardFooter>
        </Card>
      ))}
    </div>
  );
};

export default Admin;
