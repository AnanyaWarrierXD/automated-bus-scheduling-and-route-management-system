
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ContactForm from '@/components/ContactForm';

const Contact = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <div className="bg-blue-900 text-white py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl font-bold mb-4">Get in Touch</h1>
            <p className="text-xl max-w-3xl mx-auto">
              We value your feedback and suggestions. Let us know how we can improve ABSRMS
              to better serve Delhi's public transportation needs.
            </p>
          </div>
        </div>
        
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
};

export default Contact;
