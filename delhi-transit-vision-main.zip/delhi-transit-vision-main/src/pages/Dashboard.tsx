
import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchBuses, fetchRoutes, BusData, RouteData } from '@/services/api';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import DashboardPreview from '@/components/DashboardPreview';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Bus, MapPin, Route, Search, AlertTriangle, Clock } from 'lucide-react';

const Dashboard = () => {
  const [searchTerm, setSearchTerm] = useState('');

  // Fetch data using React Query
  const { 
    data: buses, 
    isLoading: busesLoading, 
    error: busesError 
  } = useQuery({
    queryKey: ['buses'],
    queryFn: fetchBuses,
  });

  const { 
    data: routes, 
    isLoading: routesLoading, 
    error: routesError 
  } = useQuery({
    queryKey: ['routes'],
    queryFn: fetchRoutes,
  });

  const filteredBuses = buses?.filter((bus) => 
    bus.routeNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bus.nextStop.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredRoutes = routes?.filter((route) =>
    route.routeNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    route.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    route.startPoint.toLowerCase().includes(searchTerm.toLowerCase()) ||
    route.endPoint.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const isLoading = busesLoading || routesLoading;
  const hasError = busesError || routesError;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1">
        <div className="bg-gray-100 py-8">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-2">ABSRMS Dashboard</h1>
            <p className="text-gray-600 mb-6">
              Explore real-time data and performance metrics for Delhi's public transportation system.
            </p>
            
            <div className="relative mb-8">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <Input
                type="text"
                placeholder="Search by route number, stop name, or location..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <Tabs defaultValue="metrics">
              <TabsList className="mb-6">
                <TabsTrigger value="metrics">Performance Metrics</TabsTrigger>
                <TabsTrigger value="buses">Bus Status</TabsTrigger>
                <TabsTrigger value="routes">Route Information</TabsTrigger>
              </TabsList>
              
              <TabsContent value="metrics">
                <DashboardPreview />
              </TabsContent>
              
              <TabsContent value="buses">
                {isLoading ? (
                  <div className="text-center py-12">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800 mb-4"></div>
                    <p>Loading bus data...</p>
                  </div>
                ) : hasError ? (
                  <div className="text-center py-12 text-red-500">
                    <AlertTriangle className="h-12 w-12 mx-auto mb-4" />
                    <p>Error loading bus data. Please try again.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredBuses && filteredBuses.length > 0 ? (
                      filteredBuses.map((bus) => (
                        <BusCard key={bus.id} bus={bus} />
                      ))
                    ) : (
                      <div className="col-span-full text-center py-8 bg-white rounded-lg shadow">
                        <p className="text-gray-500">No buses found matching your search criteria.</p>
                      </div>
                    )}
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="routes">
                {isLoading ? (
                  <div className="text-center py-12">
                    <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-gray-800 mb-4"></div>
                    <p>Loading route data...</p>
                  </div>
                ) : hasError ? (
                  <div className="text-center py-12 text-red-500">
                    <AlertTriangle className="h-12 w-12 mx-auto mb-4" />
                    <p>Error loading route data. Please try again.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {filteredRoutes && filteredRoutes.length > 0 ? (
                      filteredRoutes.map((route) => (
                        <RouteCard key={route.id} route={route} />
                      ))
                    ) : (
                      <div className="col-span-full text-center py-8 bg-white rounded-lg shadow">
                        <p className="text-gray-500">No routes found matching your search criteria.</p>
                      </div>
                    )}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

const BusCard = ({ bus }: { bus: BusData }) => {
  // Calculate time since last update
  const getTimeSinceUpdate = (lastUpdated: string) => {
    const updateTime = new Date(lastUpdated);
    const now = new Date();
    const diffMs = now.getTime() - updateTime.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 1) return 'Just now';
    if (diffMins === 1) return '1 minute ago';
    if (diffMins < 60) return `${diffMins} minutes ago`;
    
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours === 1) return '1 hour ago';
    return `${diffHours} hours ago`;
  };

  const getStatusColor = (status: string) => {
    switch(status) {
      case 'on-route': return 'bg-green-100 text-green-800';
      case 'at-depot': return 'bg-blue-100 text-blue-800';
      case 'maintenance': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="flex items-center">
              <Bus className="h-5 w-5 mr-2 text-transit-blue" />
              Bus #{bus.routeNumber}
            </CardTitle>
            <CardDescription>ID: {bus.id}</CardDescription>
          </div>
          <div className={`px-2 py-1 rounded-full text-xs ${getStatusColor(bus.status)}`}>
            {bus.status === 'on-route' ? 'On Route' : 
             bus.status === 'at-depot' ? 'At Depot' : 'Maintenance'}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">Next Stop</span>
            <span className="text-sm font-medium flex items-center">
              <MapPin className="h-4 w-4 mr-1 text-transit-orange" />
              {bus.nextStop}
            </span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">Passengers</span>
            <span className="text-sm font-medium">{bus.passengerCount} people</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">Fuel Level</span>
            <div className="flex items-center">
              <div className="w-24 bg-gray-200 rounded-full h-2 mr-2">
                <div 
                  className={`rounded-full h-2 ${
                    bus.fuelLevel > 70 ? 'bg-green-500' :
                    bus.fuelLevel > 30 ? 'bg-yellow-500' : 'bg-red-500'
                  }`} 
                  style={{ width: `${bus.fuelLevel}%` }}
                ></div>
              </div>
              <span className="text-sm font-medium">{bus.fuelLevel}%</span>
            </div>
          </div>
          
          <div className="flex justify-between pt-2 border-t border-gray-100">
            <span className="text-xs text-gray-400 flex items-center">
              <Clock className="h-3 w-3 mr-1" />
              Last updated: {getTimeSinceUpdate(bus.lastUpdated)}
            </span>
            <span className="text-xs text-blue-500 cursor-pointer hover:underline">View Details</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const RouteCard = ({ route }: { route: RouteData }) => {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="flex items-center">
              <Route className="h-5 w-5 mr-2 text-transit-green" />
              Route #{route.routeNumber}
            </CardTitle>
            <CardDescription>{route.name}</CardDescription>
          </div>
          <div className={`px-2 py-1 rounded-full text-xs ${route.activeStatus ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {route.activeStatus ? 'Active' : 'Inactive'}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center text-sm">
              <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
              <span>{route.startPoint}</span>
            </div>
            <div className="flex-1 mx-2 border-t border-dashed border-gray-300"></div>
            <div className="flex items-center text-sm">
              <span>{route.endPoint}</span>
              <div className="w-3 h-3 bg-red-500 rounded-full ml-2"></div>
            </div>
          </div>
          
          <div className="grid grid-cols-3 gap-4">
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-xs text-gray-500 mb-1">Travel Time</div>
              <div className="text-sm font-semibold">{route.averageTime} min</div>
            </div>
            
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-xs text-gray-500 mb-1">Distance</div>
              <div className="text-sm font-semibold">{route.distance} km</div>
            </div>
            
            <div className="bg-gray-50 p-3 rounded-md">
              <div className="text-xs text-gray-500 mb-1">Buses</div>
              <div className="text-sm font-semibold">{route.busCount} active</div>
            </div>
          </div>
          
          <div className="flex justify-between pt-2 border-t border-gray-100">
            <span className="text-xs text-gray-400">
              Frequency: Every {Math.round(route.averageTime / route.busCount)} min
            </span>
            <span className="text-xs text-blue-500 cursor-pointer hover:underline">View Details</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default Dashboard;
