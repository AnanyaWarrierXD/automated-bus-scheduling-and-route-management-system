
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import HeroSection from "@/components/HeroSection";
import AbstractSection from "@/components/AbstractSection";
import ArchitectureDiagram from "@/components/ArchitectureDiagram";
import FeaturesSection from "@/components/FeaturesSection";
import ImplementationTimeline from "@/components/ImplementationTimeline";
import DashboardPreview from "@/components/DashboardPreview";
import SdgContribution from "@/components/SdgContribution";
import ContactForm from "@/components/ContactForm";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <HeroSection />
        <AbstractSection />
        <ArchitectureDiagram />
        <FeaturesSection />
        <ImplementationTimeline />
        <DashboardPreview />
        <SdgContribution />
        <ContactForm />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
